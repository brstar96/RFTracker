import random

list=[['a','b','c'],['d','e','f'],['p','l','l']]
random.shuffle(list)
print(list)