import random

ResList = ['교식', '고씨네', '현선이네', '내가찜한닭', '고렝']
print(random.choice(ResList))
